const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const config = require('../config.json');

// اللوحة الرئيسية (تُرسل مرة وحدة براحة التكتات)
function buildMainPanel() {
  const embed = new EmbedBuilder()
    .setTitle(config.panelTitle || 'Master')
    .setDescription(config.panelDescription || 'اختر نوع التذكرة اللي تحتاجها 👇')
    .setColor(config.panelColor || '#8a6f66');

  if (config.panelImage) embed.setImage(config.panelImage);

  const select = new StringSelectMenuBuilder()
    .setCustomId('select_ticket_type')
    .setPlaceholder('اختر خياراً')
    .addOptions(
      config.ticketTypes.map((t) => ({
        label: t.label,
        value: t.id,
        description: t.description || undefined,
        emoji: t.emoji || undefined,
      }))
    );

  const row = new ActionRowBuilder().addComponents(select);
  return { embeds: [embed], components: [row] };
}

// امبد داخل التذكرة نفسها
function buildTicketEmbed({ typeLabel, openerId, responsibilityLabel }) {
  const embed = new EmbedBuilder()
    .setColor(config.panelColor || '#8a6f66')
    .addFields(
      { name: 'نوع التذكرة', value: typeLabel, inline: true },
      { name: 'صاحب التذكرة', value: `<@${openerId}>`, inline: true },
      {
        name: 'المسؤولية الحالية',
        value: responsibilityLabel || 'لم يتم التحويل بعد',
        inline: true,
      },
      { name: 'حالة الاستلام', value: 'لم يتم الاستلام بعد', inline: false }
    )
    .setTimestamp();
  return embed;
}

function buildTicketButtons() {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_take').setLabel('Take').setEmoji('🤝').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('ticket_manage_members').setLabel('Manage Members').setEmoji('👥').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_request_admin').setLabel('Request Admin').setEmoji('🔺').setStyle(ButtonStyle.Primary)
  );
  return row;
}

function buildTransferRow() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('select_transfer')
    .setPlaceholder('اختر المسؤولية المراد التحويل لها')
    .addOptions(
      config.responsibilities.map((r) => ({
        label: r.label,
        value: r.id,
        description: r.description || undefined,
      }))
    );
  return new ActionRowBuilder().addComponents(select);
}

function buildCloseConfirmRow() {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close_confirm').setLabel('تأكيد الإغلاق').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket_close_cancel').setLabel('إلغاء').setStyle(ButtonStyle.Secondary)
  );
  return row;
}

function buildManageMembersRow() {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('member_add').setLabel('اضافة عضو').setEmoji('➕').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('member_remove').setLabel('ازالة عضو').setEmoji('➖').setStyle(ButtonStyle.Danger)
  );
  return row;
}

module.exports = {
  buildMainPanel,
  buildTicketEmbed,
  buildTicketButtons,
  buildTransferRow,
  buildCloseConfirmRow,
  buildManageMembersRow,
};
