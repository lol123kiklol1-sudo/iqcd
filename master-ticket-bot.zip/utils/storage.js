const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'tickets.json');

function readAll() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({}, null, 2));
  }
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  try {
    return JSON.parse(raw || '{}');
  } catch {
    return {};
  }
}

function writeAll(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getTicket(channelId) {
  const all = readAll();
  return all[channelId] || null;
}

function setTicket(channelId, data) {
  const all = readAll();
  all[channelId] = { ...(all[channelId] || {}), ...data };
  writeAll(all);
  return all[channelId];
}

function deleteTicket(channelId) {
  const all = readAll();
  delete all[channelId];
  writeAll(all);
}

function nextTicketNumber() {
  const all = readAll();
  const counterPath = path.join(__dirname, '..', 'data', 'counter.json');
  let counter = { value: 0 };
  if (fs.existsSync(counterPath)) {
    counter = JSON.parse(fs.readFileSync(counterPath, 'utf8') || '{"value":0}');
  }
  counter.value += 1;
  fs.writeFileSync(counterPath, JSON.stringify(counter, null, 2));
  return counter.value;
}

module.exports = { getTicket, setTicket, deleteTicket, nextTicketNumber, readAll };
