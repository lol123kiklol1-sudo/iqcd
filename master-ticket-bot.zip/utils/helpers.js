const config = require('../config.json');

function isStaff(member) {
  if (!member) return false;
  const staffIds = new Set([
    ...(config.staffRoleIds || []),
    ...(config.responsibilities || []).map((r) => r.roleId),
    config.adminRoleId,
  ]);
  return member.roles.cache.some((role) => staffIds.has(role.id));
}

function getTicketTypeById(id) {
  return (config.ticketTypes || []).find((t) => t.id === id);
}

function getResponsibilityById(id) {
  return (config.responsibilities || []).find((r) => r.id === id);
}

module.exports = { isStaff, getTicketTypeById, getResponsibilityById };
