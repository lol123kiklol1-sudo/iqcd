require('dotenv').config();
const {
  Client,
  GatewayIntentBits,
  ChannelType,
  PermissionsBitField,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require('discord.js');

const config = require('./config.json');
const storage = require('./utils/storage');
const panel = require('./utils/panel');
const { isStaff, getTicketTypeById, getResponsibilityById } = require('./utils/helpers');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

client.once('ready', () => {
  console.log(`✅ البوت شغال باسم ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  try {
    // ===== أوامر السلاش =====
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'panel') {
        if (!interaction.memberPermissions.has(PermissionsBitField.Flags.ManageGuild)) {
          return interaction.reply({ content: 'ما تملك صلاحية استخدام هذا الأمر.', ephemeral: true });
        }
        const { embeds, components } = panel.buildMainPanel();
        await interaction.channel.send({ embeds, components });
        return interaction.reply({ content: '✅ تم إرسال لوحة التذاكر.', ephemeral: true });
      }

      if (interaction.commandName === 'close') {
        const ticket = storage.getTicket(interaction.channel.id);
        if (!ticket) {
          return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });
        }
        return interaction.reply({
          content: 'هل أنت متأكد من إغلاق التذكرة؟',
          components: [panel.buildCloseConfirmRow()],
          ephemeral: true,
        });
      }
    }

    // ===== اختيار نوع التذكرة (فتح تذكرة) =====
    if (interaction.isStringSelectMenu() && interaction.customId === 'select_ticket_type') {
      await interaction.deferReply({ ephemeral: true });

      const typeId = interaction.values[0];
      const type = getTicketTypeById(typeId);
      if (!type) return interaction.editReply({ content: 'نوع تذكرة غير معروف.' });

      const guild = interaction.guild;
      const number = storage.nextTicketNumber();
      const channelName = `ticket-${number}-${interaction.user.username}`.slice(0, 90).toLowerCase();

      const overwrites = [
        { id: guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
        {
          id: interaction.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
          ],
        },
        {
          id: client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ManageChannels,
          ],
        },
      ];

      if (type.pingRoleId && type.pingRoleId.startsWith('ضع_') === false) {
        overwrites.push({
          id: type.pingRoleId,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
          ],
        });
      }
      for (const staffId of config.staffRoleIds || []) {
        if (!staffId || staffId.startsWith('ضع_')) continue;
        overwrites.push({
          id: staffId,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
          ],
        });
      }

      const parent = config.ticketCategoryId && !config.ticketCategoryId.startsWith('ضع_')
        ? config.ticketCategoryId
        : undefined;

      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent,
        permissionOverwrites: overwrites,
      });

      storage.setTicket(channel.id, {
        openerId: interaction.user.id,
        typeId: type.id,
        typeLabel: type.label,
        responsibilityId: null,
        claimedBy: null,
        createdAt: Date.now(),
      });

      const embed = panel.buildTicketEmbed({
        typeLabel: type.label,
        openerId: interaction.user.id,
        responsibilityLabel: null,
      });

      const pingText = type.pingRoleId && !type.pingRoleId.startsWith('ضع_')
        ? `<@${interaction.user.id}> | <@&${type.pingRoleId}>`
        : `<@${interaction.user.id}>`;

      await channel.send({
        content: pingText,
        embeds: [embed],
        components: [panel.buildTicketButtons(), panel.buildTransferRow()],
      });

      await interaction.editReply({ content: `✅ تم فتح تذكرتك: ${channel}` });

      if (config.logChannelId && !config.logChannelId.startsWith('ضع_')) {
        const log = await guild.channels.fetch(config.logChannelId).catch(() => null);
        if (log) {
          log.send({
            embeds: [
              new EmbedBuilder()
                .setColor('Green')
                .setDescription(`📩 تم فتح تذكرة جديدة ${channel} بواسطة <@${interaction.user.id}> | النوع: ${type.label}`),
            ],
          });
        }
      }
      return;
    }

    // ===== تحويل التذكرة لمسؤولية =====
    if (interaction.isStringSelectMenu() && interaction.customId === 'select_transfer') {
      const ticket = storage.getTicket(interaction.channel.id);
      if (!ticket) return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });

      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: 'ما تملك صلاحية تحويل التذاكر.', ephemeral: true });
      }

      const respId = interaction.values[0];
      const resp = getResponsibilityById(respId);
      if (!resp) return interaction.reply({ content: 'مسؤولية غير معروفة.', ephemeral: true });

      // ازالة صلاحية المسؤولية القديمة (إن وجدت) واضافة الجديدة
      const oldResp = getResponsibilityById(ticket.responsibilityId);
      if (oldResp && oldResp.roleId && !oldResp.roleId.startsWith('ضع_')) {
        await interaction.channel.permissionOverwrites.delete(oldResp.roleId).catch(() => {});
      }
      if (resp.roleId && !resp.roleId.startsWith('ضع_')) {
        await interaction.channel.permissionOverwrites.edit(resp.roleId, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
        });
      }

      storage.setTicket(interaction.channel.id, { responsibilityId: resp.id });

      await interaction.reply({
        content: `🔁 تم تحويل التذكرة إلى **${resp.label}**${resp.roleId && !resp.roleId.startsWith('ضع_') ? ` <@&${resp.roleId}>` : ''} بواسطة <@${interaction.user.id}>`,
      });
      return;
    }

    // ===== زر Take (استلام التذكرة) =====
    if (interaction.isButton() && interaction.customId === 'ticket_take') {
      const ticket = storage.getTicket(interaction.channel.id);
      if (!ticket) return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: 'ما تملك صلاحية استلام التذاكر.', ephemeral: true });
      }
      if (ticket.claimedBy) {
        return interaction.reply({ content: `التذكرة مستلمة مسبقاً من <@${ticket.claimedBy}>.`, ephemeral: true });
      }
      storage.setTicket(interaction.channel.id, { claimedBy: interaction.user.id });
      await interaction.reply({ content: `🤝 تم استلام التذكرة من قبل <@${interaction.user.id}>` });
      return;
    }

    // ===== زر Request Admin =====
    if (interaction.isButton() && interaction.customId === 'ticket_request_admin') {
      const ticket = storage.getTicket(interaction.channel.id);
      if (!ticket) return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });

      const adminId = config.adminRoleId;
      const mention = adminId && !adminId.startsWith('ضع_') ? `<@&${adminId}>` : 'الإدارة';
      await interaction.reply({ content: `🔺 تم طلب حضور الإدارة: ${mention} بواسطة <@${interaction.user.id}>` });
      return;
    }

    // ===== زر Manage Members =====
    if (interaction.isButton() && interaction.customId === 'ticket_manage_members') {
      const ticket = storage.getTicket(interaction.channel.id);
      if (!ticket) return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: 'ما تملك صلاحية إدارة أعضاء التذكرة.', ephemeral: true });
      }
      return interaction.reply({
        content: 'اختر الإجراء:',
        components: [panel.buildManageMembersRow()],
        ephemeral: true,
      });
    }

    if (interaction.isButton() && (interaction.customId === 'member_add' || interaction.customId === 'member_remove')) {
      const isAdd = interaction.customId === 'member_add';
      const modal = new ModalBuilder()
        .setCustomId(isAdd ? 'modal_add_member' : 'modal_remove_member')
        .setTitle(isAdd ? 'اضافة عضو للتذكرة' : 'ازالة عضو من التذكرة');

      const input = new TextInputBuilder()
        .setCustomId('member_id')
        .setLabel('آيدي العضو (User ID)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('مثال: 123456789012345678')
        .setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(input));
      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && (interaction.customId === 'modal_add_member' || interaction.customId === 'modal_remove_member')) {
      const isAdd = interaction.customId === 'modal_add_member';
      const memberId = interaction.fields.getTextInputValue('member_id').trim();

      const member = await interaction.guild.members.fetch(memberId).catch(() => null);
      if (!member) {
        return interaction.reply({ content: '⚠️ ما قدرت ألقى عضو بهذا الآيدي.', ephemeral: true });
      }

      if (isAdd) {
        await interaction.channel.permissionOverwrites.edit(member.id, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
        });
        await interaction.reply({ content: `➕ تم اضافة <@${member.id}> للتذكرة بواسطة <@${interaction.user.id}>` });
      } else {
        await interaction.channel.permissionOverwrites.delete(member.id).catch(() => {});
        await interaction.reply({ content: `➖ تم ازالة <@${member.id}> من التذكرة بواسطة <@${interaction.user.id}>` });
      }
      return;
    }

    // ===== زر Close =====
    if (interaction.isButton() && interaction.customId === 'ticket_close') {
      const ticket = storage.getTicket(interaction.channel.id);
      if (!ticket) return interaction.reply({ content: 'هذا الروم مو تذكرة.', ephemeral: true });

      const isOwner = ticket.openerId === interaction.user.id;
      if (!isOwner && !isStaff(interaction.member)) {
        return interaction.reply({ content: 'ما تملك صلاحية إغلاق هذي التذكرة.', ephemeral: true });
      }

      return interaction.reply({
        content: 'هل أنت متأكد من إغلاق التذكرة؟ راح يتم حذف الروم خلال 5 ثواني بعد التأكيد.',
        components: [panel.buildCloseConfirmRow()],
        ephemeral: true,
      });
    }

    if (interaction.isButton() && interaction.customId === 'ticket_close_cancel') {
      return interaction.update({ content: '❌ تم إلغاء الإغلاق.', components: [] });
    }

    if (interaction.isButton() && interaction.customId === 'ticket_close_confirm') {
      const ticket = storage.getTicket(interaction.channel.id);
      await interaction.update({ content: '🔒 يتم إغلاق التذكرة...', components: [] });

      if (config.logChannelId && !config.logChannelId.startsWith('ضع_')) {
        const log = await interaction.guild.channels.fetch(config.logChannelId).catch(() => null);
        if (log && ticket) {
          log.send({
            embeds: [
              new EmbedBuilder()
                .setColor('Red')
                .setDescription(`🔒 تم إغلاق التذكرة **#${interaction.channel.name}** بواسطة <@${interaction.user.id}>\nالنوع: ${ticket.typeLabel}\nصاحب التذكرة: <@${ticket.openerId}>`),
            ],
          });
        }
      }

      storage.deleteTicket(interaction.channel.id);
      setTimeout(() => {
        interaction.channel.delete().catch(() => {});
      }, 5000);
      return;
    }
  } catch (err) {
    console.error(err);
    if (interaction.isRepliable()) {
      interaction
        .reply({ content: '⚠️ صار خطأ غير متوقع، حاول مرة ثانية.', ephemeral: true })
        .catch(() => {});
    }
  }
});

client.login(process.env.TOKEN);
